//1. 
public class Main {
    public static void main(String[] args) {
        Animal a = new Dog();
        a.makeSound();
    }
}

class Animal {
    public void makeSound() {
        System.out.println("Animal sound");
    }
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Bark");
    }
}

//2. 
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        System.out.println(list.get(3));
    }
}

//3.
public class Main {
    public static void main(String[] args) {
        B b = new B();
    }
}

class A {
    public A() {
        System.out.println("A's constructor");
    }
}

class B extends A {
    public B() {
        super();
        System.out.println("B's constructor");
    }
}

//4.
public class Main {
    public static void main(String[] args) {
        C c = new C();
        c.display();
    }
}

class B {
    public void display() {
        System.out.println("Display from B");
    }
}

class C extends B {
    @Override
    public void display() {
        System.out.println("Display from C");
    }
}

//5.
public class Main {
    public static void main(String[] args) {
        D d = new D();
        System.out.println(d.getVal());
    }
}

class C {
    private int val;

    public C(int v) {
        val = v;
    }

    public int getVal() {
        return val;
    }
}

class D extends C {
    public D() {
        super(5);
    }
}