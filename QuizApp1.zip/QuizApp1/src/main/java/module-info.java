module com.example.quizapp1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.quizapp1 to javafx.fxml;
    exports com.example.quizapp1;
}