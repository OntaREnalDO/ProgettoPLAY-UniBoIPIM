//1 stampa di "Hello, World!"
public class Main {
    public static void main(String[] args) {
        /*[Risposta]*/
    }
}

//2 somma di a + b
public class Main {
    public static void main(String[] args) {
        int a = 5;
        int b = 3;
        /*[Risposta]*/
    }
}

//3 confronto di a e b in modo che a sia minore di b
public class Main {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        /*[Risposta]*/ {
            System.out.println("a � minore di b");
        }
    }
}

//4 stampare numeri da 1 a 5
public class Main {
    public static void main(String[] args) {
        /*[Risposta]*/ {
            System.out.println(i);
        }
    }
}

//5 calcolare lunghezza di una stringa
public class Main {
    public static void main(String[] args) {
        String str = "hello";
        System.out.println(/*[Risposta]*/);
    }
}

//6 controlla se un numero (num) � pari
public class Main {
    public static void main(String[] args) {
        int num = 4;
        /*[Risposta]*/ {
            System.out.println("Il numero � pari");
        }
    }
}

//7 stampare i numeri pari da 1 a 10
public class Main {
    public static void main(String[] args) {
        /*[Risposta]*/
                System.out.println(i);
            }
        }
    }
}

//8 somma degli elementi di un array
public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int sum = 0;
        /*[Risposta]*/ {
            sum += num;
        }
        System.out.println(sum);
    }
}

//9 moltiplicare a per b
public class Main {
    public static void main(String[] args) {
        int a = 6;
        int b = 7;
        /*[Risposta]*/
    }
}

//10 stampare il terzo carattere della stringa
public class Main {
    public static void main(String[] args) {
        String str = "hello";
        System.out.println(/*[Risposta]*/);
    }
}



















