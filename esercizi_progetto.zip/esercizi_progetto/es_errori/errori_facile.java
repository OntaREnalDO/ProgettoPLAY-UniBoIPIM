//1
public class Main {
    public static void main(String[] args) {
        int a = "5";
        int b = 3;
        System.out.println(a + b);
    }
}

//2
public class Main {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i--) {
            System.out.print(i + " ");
        }
    }
}

//3
public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3};
        for (int i = 0; i <= arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}

//4
public class Main {
    public static void main(String[] args) {
        int x = 10;
        if (x = 5) {
            System.out.println("x is 5");
        } else {
            System.out.println("x is not 5");
        }
    }
}

//5
public class Main {
    public static void main(String[] args) {
        String str = "Hello";
        for (int i = 0; i <= str.length(); i++) {
            System.out.print(str.charAt(i));
        }
    }
}
