//1
public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        System.out.println(sum(arr));
    }

    public static int sum(int arr[]) {
        int total = 0;
        for (int i = 0; i <= arr.length; i++) {
            total += arr[i];
        }
        return total;
    }
}

//2
public class Main {
    public static void main(String[] args) {
        System.out.println(factorial(5));
    }

    public static int factorial(int n) {
        if (n = 0) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }
}

//3
public class Main {
    public static void main(String[] args) {
        Person p = new Person();
        p.setName("Alice");
        System.out.println(p.getName());
    }
}

class Person {
    private String name;

    public void setName(String name) {
        this.name == name;
    }

    public String getName() {
        return name;
    }
}

//4
public class Main {
    public static void main(String[] args) {
        Car myCar = new Car("Red");
        System.out.println(myCar.getColor());
    }
}

class Car {
    private String color;

    public Car(String c) {
        color = c;
    }

    public String getColor() {
        return Colour;
    }
}

//5
public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int target = 3;
        boolean found = false;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                found = true;
                break;
            }
        }
        System.out.println(found);
    }
}











