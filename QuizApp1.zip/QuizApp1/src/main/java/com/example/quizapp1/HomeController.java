package com.example.quizapp1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeController {

    // Gestisce il clic sul pulsante "Completa la frase"
    @FXML
    private void handleCompletaFrase() throws IOException {
        loadDifficultySelection("CompletaFrase");
    }

    // Gestisce il clic sul pulsante "Cosa stampa"
    @FXML
    private void handleCosaStampa() throws IOException {
        loadDifficultySelection("CosaStampa");
    }

    // Gestisce il clic sul pulsante "Trova l'errore"
    @FXML
    private void handleTrovaErrore() throws IOException {
        loadDifficultySelection("TrovaErrore");
    }

    // Gestisce il clic sul pulsante "Quiz"
    @FXML
    private void handleQuiz() throws IOException {
        loadDifficultySelection("QuizApp");
    }

    // Carica la finestra di selezione della difficoltà
    private void loadDifficultySelection(String exerciseType) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SelectDifficulty.fxml"));
        Parent root = loader.load();

        SelectDifficultyController controller = loader.getController();
        controller.setExerciseType(exerciseType);

        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Seleziona Difficoltà");
        stage.show();
    }
}
