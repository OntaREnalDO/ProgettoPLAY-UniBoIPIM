package com.example.quizapp1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SelectDifficultyController {

    private String exerciseType;  // Variabile per memorizzare il tipo di esercizio selezionato

    // Metodo per impostare il tipo di esercizio
    public void setExerciseType(String exerciseType) {
        this.exerciseType = exerciseType;
    }

    // Gestisce il clic sul pulsante "Facile"
    @FXML
    private void handleEasy() throws IOException {
        loadExercise("easy");
    }

    // Gestisce il clic sul pulsante "Intermedio"
    @FXML
    private void handleIntermediate() throws IOException {
        loadExercise("intermediate");
    }

    // Gestisce il clic sul pulsante "Esperto"
    @FXML
    private void handleExpert() throws IOException {
        loadExercise("expert");
    }

    // Carica l'esercizio in base alla difficoltà selezionata
    private void loadExercise(String difficulty) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(exerciseType + ".fxml"));
        Parent root = loader.load();

        Object controller = loader.getController();
        // Imposta la difficoltà nel controller specifico dell'esercizio
        if (controller instanceof QuizAppController) {
            ((QuizAppController) controller).setDifficulty(difficulty);
        } else if (controller instanceof CosaStampaController) {
            ((CosaStampaController) controller).setDifficulty(difficulty);
        } else if (controller instanceof TrovaErroreController) {
            ((TrovaErroreController) controller).setDifficulty(difficulty);
        } else if (controller instanceof CompletaFraseController) {
            ((CompletaFraseController) controller).setDifficulty(difficulty);
        }

        // Mostra la scena dell'esercizio
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle(exerciseType + " - " + difficulty);
        stage.show();
    }
}
