//1 secondo massimo array
public class Main {
    public static void main(String[] args) {
        int[] arr = {3, 5, 7, 2, 8};
        int max1 = Integer.MIN_VALUE;
        int max2 = Integer.MIN_VALUE;
        for (int num : arr) {
            /*[Risposta1]*/ {
                max2 = max1;
                max1 = num;
            } /*[Risposta2]*/ {
                max2 = num;
            }
        }
        System.out.println(max2);
    }
}

//2 matrice � simmetrica
public class Main {
    public static void main(String[] args) {
        int[][] matrix = {
            {1, 2, 3},
            {2, 1, 4},
            {3, 4, 1}
        };
        boolean isSymmetric = true;
        // Scegli la risposta corretta per verificare se la matrice � simmetrica
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                /*[Risposta]*/{
                    isSymmetric = false;
                    break;
                }
            }
        }
        System.out.println(isSymmetric);
    }
}

//3 rotazione di un array a dx
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int n = 2; // numero di rotazioni
        // Scegli la risposta corretta per ruotare l'array a destra di n posizioni
        int[] rotated = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            rotated[(i + n) % arr.length] = arr[i];
        }
        System.out.println(Arrays.toString(rotated));
    }
}

//4 merge sort
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] arr1 = {1, 3, 5};
        int[] arr2 = {2, 4, 6};
        int[] merged = new int[arr1.length + arr2.length];
        int i = 0, j = 0, k = 0;
        while (i < arr1.length && j < arr2.length) {
            /*[Risposta]*/ {
                merged[k++] = arr1[i++];
            } else {
                merged[k++] = arr2[j++];
            }
        }
        while (i < arr1.length) {
            merged[k++] = arr1[i++];
        }
        while (j < arr2.length) {
            merged[k++] = arr2[j++];
        }
        System.out.println(Arrays.toString(merged));
    }
}

// 5. bubblee sort
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] arr = {5, 3, 8, 4, 2};
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                /*[Risposta]*/ {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}



















