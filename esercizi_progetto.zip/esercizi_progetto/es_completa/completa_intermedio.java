//1 invertire una stringa
public class Main {
    public static void main(String[] args) {
        String str = "hello";
        String reversed = "";
        /*[Risposta]*/{
        	reversed += str.charAt(i);        
        }
        System.out.println(reversed);
    }
}

//2 fattoriale di un numero 5
public class Main {
    public static void main(String[] args) {
        int num = 5;
        int factorial = 1;
        for (int i = 1; i <= num; i++) {
        	/*[Risposta]*/
        }
        System.out.println(factorial);
    }
}

//3 contare le vocali in una stringa
public class Main {
    public static void main(String[] args) {
        String str = "hello world";
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            /*[Risposta]*/ {
                count++;
            }
        }
        System.out.println(count);
    }
}

//4 Verificarese una stringa � palindromo
public class Main {
    public static void main(String[] args) {
        String str = "radar";
        boolean isPalindrome = true;
        for (int i = 0; i < str.length() / 2; i++) {
            /*[Risposta]*/ {
                isPalindrome = false;
                break;
            }
        }
        System.out.println(isPalindrome);
    }
}

//5 trova il massimo di un array
public class Main {
    public static void main(String[] args) {
        int[] arr = {3, 5, 7, 2, 8, 11, 1, 4, 6};
        int max = arr[0];
        // Scegli la risposta corretta per trovare il massimo elemento dell'array
        for (int i = 1; i < arr.length; i++) {
            /*[Risposta]*/ {
                max = arr[i];
            }
        }
        System.out.println(max);
    }
}






























