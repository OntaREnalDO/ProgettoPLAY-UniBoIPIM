//1 Ereditariet�
public class Main {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.makeSound();
    }
}

class Animal {
    public void makeSound() {
        System.out.println("Animal sound");
    }
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Bark");
    }
}

//2 Polimorfismo
public class Main {
    public static void main(String[] args) {
        Animal a = new Dog();
        a.makeSound();
    }
}

class Animal {
    public void makeSound() {
        System.out.println("Animal sound");
    }
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Bark");
    }
}

//3 ArrayList
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        System.out.println(list.get(1));
    }
}

//4. Ereditariet� e costruttori
public class Main {
    public static void main(String[] args) {
        B b = new B();
    }
}

class A {
    public A() {
        System.out.println("Costruttore A");
    }
}

class B extends A {
    public B() {
        System.out.println("Costruttore B");
    }
}

//5. Override metodi
public class Main {
    public static void main(String[] args) {
        C c = new C();
        c.display();
    }
}

class B {
    public void display() {
        System.out.println("Display from B");
    }
}

class C extends B {
    @Override
    public void display() {
        System.out.println("Display from C");
    }
}




