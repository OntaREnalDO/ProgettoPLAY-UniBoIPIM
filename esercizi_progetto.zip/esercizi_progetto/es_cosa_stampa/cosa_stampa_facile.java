// 1. somma di due numeri
public class Main {
    public static void main(String[] args) {
        int a = 5;
        int b = 3;
        System.out.println(a + b);
    }
}

//2. ciclo for
public static void main(String[] args) {
    for (int i = 0; i < 3; i++) {
        System.out.print(i + " ");
    }
}

//3. ciclo while
public class Main {
    public static void main(String[] args) {
        int i = 3;
        while (i > 0) {
            System.out.print(i + " ");
            i--;
        }
    }
}

//4. variabili e operatori
public class Main {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = a * b / 2;
        System.out.println(c);
    }
}

//5. break
public class Main {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            if (i == 3) {
                break;
            }
            System.out.print(i + " ");
        }
    }
}